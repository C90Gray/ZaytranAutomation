﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class User
    {
        public float UserMa { get; set; }
        public float UserMb { get; set; }
    }
}