﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class GripperModels
    {
        public List<Specs> Specs { get; set; }
        public User User { get; set; }
    }
}