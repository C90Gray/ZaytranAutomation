﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;

namespace WebApplication1.Models
{
    public class Email
    {
        public string Username { get; set; }
        public string EmailAdd { get; set; }
    }
}